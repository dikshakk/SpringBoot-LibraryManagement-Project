package com.example.Library.Mangement;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {


		@Autowired
		UserRepository userRepository;
		
		@GetMapping("/")
		public String home() {
			System.out.println("I am doprint");
			//return "Hello Spring Security <a href= \"http://localhost:8080/\" > click here </a>" ;
			return "/index";
			
		}

		@RequestMapping(value = "/save", method = RequestMethod.POST)
		public ModelAndView save(@ModelAttribute UserEntity userEntity) {
			userRepository.save(userEntity);
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("user-data");
			modelAndView.addObject("userEntity", userEntity);
			return modelAndView;
		}

		/*
		 * @GetMapping("/test") public String testMethod() {
		 * return"This is test method!!!"; }
		 */

		@PostMapping("/insert")
		public String insertData(@RequestBody UserEntity studentEntity) {
			userRepository.save(studentEntity);
			//return "data saved successfuly!!";
			return "index";

		}

		@GetMapping("/get")
		public List<UserEntity> getData() {
			userRepository.findAll();
			return userRepository.findAll();
		}

		@GetMapping("/get/{id}")
		public Optional<UserEntity> getData(@PathVariable Long id) {
			// return studentRepository.findById(id).toString();
			return userRepository.findById(id);

		}

		@PutMapping("/update/{id}")
		public Optional<UserEntity> updateData(@RequestBody UserEntity studentEntity, @PathVariable Long id) {
			userRepository.save(studentEntity);
			// return studentRepository.findAll();
			return userRepository.findById(id);

		}

		@DeleteMapping("/delete/{id}")
		public String delete(@PathVariable Long id) {
			userRepository.deleteById(id);
			return "Data deleted successfuly";

		}

	}


