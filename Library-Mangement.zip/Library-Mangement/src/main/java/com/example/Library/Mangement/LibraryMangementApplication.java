package com.example.Library.Mangement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryMangementApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryMangementApplication.class, args);
	}

}
