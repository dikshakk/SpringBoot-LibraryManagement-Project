package com.example.Library.Mangement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryMangementApplicationTests {

	@Test
	void contextLoads() {
	}

}
